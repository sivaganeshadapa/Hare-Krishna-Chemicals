import React from 'react';
import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';
import Hero from './components/home/Hero';
import About from './components/home/About';
import Products from './components/home/Products';
import Clients from './components/home/Clients';
import Research from './components/home/Research';
import Sustainability from './components/home/Sustainability';
import Compliance from './components/home/Compliance';
import Contact from './components/home/Contact';
import './styles/animations.css';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Products />
        <Clients />
        <Research />
        <Sustainability />
        <Compliance />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;