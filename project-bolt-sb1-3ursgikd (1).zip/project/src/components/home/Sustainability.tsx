import React from 'react';
import Section from '../ui/Section';
import SectionHeading from '../ui/SectionHeading';
import { Droplets, Sprout, Recycle, Zap, PackagePlus } from 'lucide-react';

interface SustainabilityInitiativeProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const SustainabilityInitiative: React.FC<SustainabilityInitiativeProps> = ({
  icon,
  title,
  description
}) => {
  return (
    <div className="flex items-start">
      <div className="mr-4 bg-green-100 p-3 rounded-full text-green-600">
        {icon}
      </div>
      <div>
        <h3 className="font-semibold text-lg mb-2">{title}</h3>
        <p className="text-gray-600">{description}</p>
      </div>
    </div>
  );
};

const Sustainability: React.FC = () => {
  return (
    <Section id="sustainability" bgColor="bg-white">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div>
          <SectionHeading 
            title="Our Commitment to Sustainability" 
            subtitle="We believe in responsible manufacturing that protects our environment and communities."
          />
          
          <div className="space-y-8">
            <SustainabilityInitiative 
              icon={<Droplets size={24} />}
              title="Water Management"
              description="Our advanced RO+ETP wastewater systems ensure that water discharged from our facilities meets or exceeds regulatory standards, minimizing environmental impact."
            />
            
            <SustainabilityInitiative 
              icon={<Sprout size={24} />}
              title="Green Chemistry"
              description="We implement green chemistry principles in our formulations, reducing hazardous substances and developing more environmentally friendly alternatives."
            />
            
            <SustainabilityInitiative 
              icon={<Recycle size={24} />}
              title="Waste Reduction"
              description="Through careful process optimization and recycling initiatives, we continually work to reduce waste generation and increase resource efficiency."
            />
            
            <SustainabilityInitiative 
              icon={<Zap size={24} />}
              title="Energy Efficiency"
              description="Our energy-efficient manufacturing units incorporate modern technology to reduce power consumption and lower our carbon footprint."
            />
            
            <SustainabilityInitiative 
              icon={<PackagePlus size={24} />}
              title="Sustainable Packaging"
              description="We're transitioning to reduced plastic packaging options and exploring biodegradable alternatives for our product containers."
            />
          </div>
          
          <div className="mt-8 p-5 bg-green-50 rounded-lg border border-green-100">
            <h3 className="font-semibold text-lg mb-2 text-green-700">ISO-14001 Compliance</h3>
            <p className="text-gray-600">
              We're proud to maintain ISO-14001 compliance, demonstrating our commitment to 
              effective environmental management systems throughout our operations.
            </p>
          </div>
        </div>
        
        <div className="relative">
          <div className="grid grid-cols-2 gap-4">
            <img 
              src="https://t4.ftcdn.net/jpg/02/46/77/29/240_F_246772962_qHJsTucirASR4D77EhhdMDYqVgMKqwPW.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
              alt="Sustainable manufacturing" 
              className="rounded-lg shadow-md h-64 object-cover w-full"
            />
            <img 
              src="https://t3.ftcdn.net/jpg/02/00/63/44/240_F_200634426_XlSfjJTw4y49AbWdJNNLCXvDopoHPhDm.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
              alt="Green chemistry" 
              className="rounded-lg shadow-md h-64 object-cover w-full mt-8"
            />
            <img 
              src="https://t3.ftcdn.net/jpg/02/71/86/78/240_F_271867817_QnqS8K9x8XOOGaUEIdrLKb1sLvB7rhU7.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
              alt="Laboratory testing" 
              className="rounded-lg shadow-md h-64 object-cover w-full"
            />
            <img 
              src="https://t3.ftcdn.net/jpg/02/80/17/28/240_F_280172859_JeQMfOmvLy89bPmNBZAxuAODp59DgHyp.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
              alt="Water treatment" 
              className="rounded-lg shadow-md h-64 object-cover w-full mt-8"
            />
          </div>
          
          <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-green-100 rounded-full -z-10"></div>
          <div className="absolute -top-4 -right-4 w-24 h-24 bg-blue-100 rounded-full -z-10"></div>
        </div>
      </div>
    </Section>
  );
};

export default Sustainability;