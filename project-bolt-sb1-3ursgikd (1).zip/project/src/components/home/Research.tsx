import React from 'react';
import Section from '../ui/Section';
import SectionHeading from '../ui/SectionHeading';
import { Beaker, Microscope, FlaskConical } from 'lucide-react';

const ResearchCard: React.FC<{
  icon: React.ReactNode;
  title: string;
  description: string;
}> = ({ icon, title, description }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
      <div className="text-primary-600 mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-3">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

const PipelineProject: React.FC<{
  title: string;
  stage: string;
  description: string;
}> = ({ title, stage, description }) => {
  const getStageColor = (stage: string) => {
    switch (stage.toLowerCase()) {
      case 'research':
        return 'bg-blue-100 text-blue-800';
      case 'development':
        return 'bg-purple-100 text-purple-800';
      case 'testing':
        return 'bg-amber-100 text-amber-800';
      case 'scaling':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="border border-gray-200 rounded-lg p-5">
      <div className="flex justify-between items-start mb-3">
        <h4 className="font-semibold text-lg">{title}</h4>
        <span className={`px-2 py-1 rounded text-xs font-medium ${getStageColor(stage)}`}>
          {stage}
        </span>
      </div>
      <p className="text-gray-600 text-sm">{description}</p>
    </div>
  );
};

const Research: React.FC = () => {
  return (
    <Section id="research" bgColor="bg-gray-50">
      <SectionHeading 
        title="R&D and Innovation" 
        subtitle="Our research focus is on developing sustainable and effective formulations."
        center
      />
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
        <ResearchCard 
          icon={<Beaker size={36} />}
          title="Advanced Equipment"
          description="Our state-of-the-art laboratory is equipped with the latest analytical instruments for precise formulation development and testing."
        />
        
        <ResearchCard 
          icon={<Microscope size={36} />}
          title="Expert Research Team"
          description="With over 10 years of R&D experience, our team brings deep expertise in agrochemical formulation science."
        />
        
        <ResearchCard 
          icon={<FlaskConical size={36} />}
          title="Sustainable Solutions"
          description="We focus on developing eco-friendly solvent systems and formulations that minimize environmental impact."
        />
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-8">
        <h3 className="text-2xl font-semibold mb-6 text-center">Pipeline Projects</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <PipelineProject 
            title="Nano Formulations"
            stage="Development"
            description="Ultra-efficient delivery systems using nanoparticle technology for reduced application rates and improved efficacy."
          />
          
          <PipelineProject 
            title="Biodegradable Surfactants"
            stage="Testing"
            description="Plant-derived surfactants that provide excellent performance while breaking down naturally in the environment."
          />
          
          <PipelineProject 
            title="Smart-Release Capsules"
            stage="Research"
            description="Controlled-release technology that responds to environmental triggers for optimized active ingredient delivery."
          />
          
          <PipelineProject 
            title="Water-Based Formulations"
            stage="Scaling"
            description="Reducing organic solvent use with advanced water-based systems that maintain efficacy and stability."
          />
          
          <PipelineProject 
            title="Bio-Stimulant Complexes"
            stage="Scaling"
            description="Combining traditional agrochemicals with natural bio-stimulants for enhanced crop resilience and yield."
          />
          
          <PipelineProject 
            title="Precision Agriculture Solutions"
            stage="Research"
            description="Specialized formulations designed for drone application and precision agriculture technologies."
          />
        </div>
        
        <div className="mt-8 p-5 border border-primary-100 bg-primary-50 rounded-lg">
          <h4 className="text-lg font-semibold mb-2 text-primary-700">Research Collaboration</h4>
          <p className="text-gray-600">
            We welcome collaboration with agricultural universities and research institutions. 
            Contact us to explore potential research partnerships in sustainable agrochemical development.
          </p>
        </div>
      </div>
    </Section>
  );
};

export default Research;