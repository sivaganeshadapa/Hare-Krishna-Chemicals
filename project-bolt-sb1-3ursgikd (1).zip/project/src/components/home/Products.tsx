import React from 'react';
import Section from '../ui/Section';
import SectionHeading from '../ui/SectionHeading';
import { Check } from 'lucide-react';

const ProductCard: React.FC<{
  title: string;
  description: string;
  icon: string;
}> = ({ title, description, icon }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
      <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center mb-4">
        <span className="text-primary-600 text-xl">{icon}</span>
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

const ProductFeature: React.FC<{
  title: string;
  features: string[];
}> = ({ title, features }) => {
  return (
    <div className="mb-8">
      <h3 className="text-xl font-semibold mb-4 text-primary-700">{title}</h3>
      <ul className="space-y-2">
        {features.map((feature, index) => (
          <li key={index} className="flex items-start">
            <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
            <span className="text-gray-600">{feature}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

const Products: React.FC = () => {
  const productCategories = [
    
    { 
      title: 'Bio-Stimulant', 
      description: 'Plant growth enhancers that improve nutrient uptake, stress tolerance, and yield—derived from organic sources.', 
      icon: '🌾' 
    },
    { 
      title: 'Bio-Pesticides', 
      description: 'Eco-friendly pest control derived from natural sources like bacteria, fungi, and plant extracts.', 
      icon: '🧪' 
    },
    { 
      title: 'Bio-Fungicides', 
      description: 'Eco-friendly fungal control agents developed from naturally occurring organisms.', 
      icon: '🐞' 
    },
    { 
      title: 'PGRs', 
      description: 'Plant growth regulators for enhanced crop performance.', 
      icon: '🌿' 
    },
    { 
      title: 'Micronutrients', 
      description: 'Essential trace elements like zinc, boron, iron, etc., that support healthy crop development.', 
      icon: '🦠' 
    },
    { 
      title: 'Bio-Fertilizers', 
      description: 'Natural fertilizers that enhance soil fertility and plant growth using beneficial microorganisms.', 
      icon: '🌱' 
    },
    
    { 
      title: 'Organic Fertilizers', 
      description: 'Nutrient-rich fertilizers derived from organic matter for sustainable agriculture.', 
      icon: '🍄' 
    },
    { 
      title: 'Water-Soluble Solvents', 
      description: 'High-purity chemical solvents that dissolve easily in water — used in advanced agro formulations.', 
      icon: '💧' 
    },
    
    { 
      title: 'Intermediates', 
      description: 'Chemical building blocks for various agrochemical formulations.', 
      icon: '⚗️' 
    },
    { 
      title: 'Solvents', 
      description: 'High-purity solvents for chemical processes and formulations.', 
      icon: '🪨' 
    }
  ];

  return (
    <Section id="products" bgColor="bg-gray-50">
      <SectionHeading 
        title="Products & Services" 
        subtitle="High-quality chemical formulations for diverse agricultural needs."
        center
      />
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
        {productCategories.map((product, index) => (
          <ProductCard 
            key={index}
            title={product.title}
            description={product.description}
            icon={product.icon}
          />
        ))}
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-8 mt-12">
        <h3 className="text-2xl font-semibold mb-6 text-center">Our Capabilities</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <ProductFeature 
            title="Formulation Types"
            features={[
              'Liquid formulations',
              'Powder preparations',
              'Emulsifiable concentrates',
              'Custom packaging solutions',
              'Eco-friendly solvent systems'
            ]}
          />
          
          <ProductFeature 
            title="Quality Control"
            features={[
              'GC/HPLC/UV analysis',
              'Microbial testing',
              'Stability assessments',
              'In-house quality checks',
              'Batch consistency verification'
            ]}
          />
          
          <ProductFeature 
            title="Additional Services"
            features={[
              'Custom formulation development',
              'Regulatory documentation support',
              'Technical consulting',
              'Product optimization',
              'Small batch testing'
            ]}
          />
        </div>
      </div>
    </Section>
  );
};

export default Products;