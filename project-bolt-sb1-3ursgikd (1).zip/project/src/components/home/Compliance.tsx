import React from 'react';
import Section from '../ui/Section';
import SectionHeading from '../ui/SectionHeading';
import { ShieldCheck, FileCheck, FileText, AlertTriangle, Check } from 'lucide-react';

interface ComplianceCertificateProps {
  title: string;
  status: 'certified' | 'pending' | 'compliant';
  description: string;
  icon: React.ReactNode;
}

const ComplianceCertificate: React.FC<ComplianceCertificateProps> = ({
  title,
  status,
  description,
  icon
}) => {
  const getStatusColor = () => {
    switch (status) {
      case 'certified':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'pending':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'compliant':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusText = () => {
    switch (status) {
      case 'certified':
        return 'Certified';
      case 'pending':
        return 'Pending';
      case 'compliant':
        return 'Compliant';
      default:
        return 'Unknown';
    }
  };

  return (
    <div className={`border rounded-lg p-5 ${getStatusColor()}`}>
      <div className="flex items-start">
        <div className="mr-4">
          {icon}
        </div>
        <div>
          <div className="flex items-center mb-2">
            <h3 className="font-semibold text-lg mr-2">{title}</h3>
            <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
              status === 'certified' ? 'bg-green-200 text-green-800' :
              status === 'pending' ? 'bg-amber-200 text-amber-800' :
              'bg-blue-200 text-blue-800'
            }`}>
              {getStatusText()}
            </span>
          </div>
          <p className="text-sm">{description}</p>
        </div>
      </div>
    </div>
  );
};

const ComplianceFeature: React.FC<{
  text: string;
}> = ({ text }) => {
  return (
    <div className="flex items-center">
      <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
      <span className="text-gray-600">{text}</span>
    </div>
  );
};

const Compliance: React.FC = () => {
  return (
    <Section id="compliance" bgColor="bg-gray-50">
      <SectionHeading 
        title="Compliance & Certifications" 
        subtitle="We adhere to stringent quality and safety standards to ensure product excellence."
        center
      />
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
        <ComplianceCertificate 
          title="ISO 9001:2015"
          status="certified"
          description="Our quality management system is certified to ISO 9001:2015 standards, ensuring consistent quality across all processes."
          icon={<ShieldCheck className="h-6 w-6 text-green-700" />}
        />
        
       
        
        <ComplianceCertificate 
          title="REACH Registration"
          status="pending"
          description="Currently in process for Registration, Evaluation, Authorization and Restriction of Chemicals (REACH) compliance."
          icon={<FileText className="h-6 w-6 text-amber-700" />}
        />
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-8">
        <h3 className="text-2xl font-semibold mb-6 text-center">Documentation & Safety</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h4 className="text-xl font-semibold mb-4 text-primary-700">Available Documentation</h4>
            <div className="space-y-3">
              <ComplianceFeature text="Material Safety Data Sheets (MSDS)" />
              <ComplianceFeature text="Certificate of Analysis (COA)" />
              <ComplianceFeature text="Product Specification Sheets" />
              <ComplianceFeature text="Regulatory Compliance Certificates" />
              <ComplianceFeature text="Quality Control Reports" />
            </div>
          </div>
          
          <div>
            <h4 className="text-xl font-semibold mb-4 text-primary-700">Safety Protocols</h4>
            <div className="space-y-3">
              <ComplianceFeature text="Regular safety training for all personnel" />
              <ComplianceFeature text="Strict adherence to personal protective equipment requirements" />
              <ComplianceFeature text="Emergency response procedures" />
              <ComplianceFeature text="Regular safety audits and inspections" />
              <ComplianceFeature text="Hazard communication systems" />
            </div>
          </div>
        </div>
        
        <div className="mt-8 p-5 border border-primary-100 bg-primary-50 rounded-lg">
          <h4 className="text-lg font-semibold mb-2 text-primary-700">Our Compliance Commitment</h4>
          <p className="text-gray-600">
            We're committed to maintaining the highest standards of compliance in all aspects of our operations. 
            Our dedicated compliance team stays up-to-date with regulatory changes to ensure our products 
            and processes always meet or exceed industry requirements.
          </p>
        </div>
      </div>
    </Section>
  );
};

export default Compliance;