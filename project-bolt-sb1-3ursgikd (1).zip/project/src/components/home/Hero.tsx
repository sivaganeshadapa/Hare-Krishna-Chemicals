import React from 'react';
import Button from '../ui/Button';

const Hero: React.FC = () => {
  return (
    <div id="home" className="relative pt-24 bg-gradient-to-b from-primary-50 to-white overflow-hidden">
      <div className="absolute inset-0 z-0 bg-[url('https://t3.ftcdn.net/jpg/02/16/53/40/240_F_216534086_SiTIgc7QKTvcbbLAKXCIeaJYVEuPJRbb.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1')] bg-cover bg-center opacity-10"></div>
      <div className="container mx-auto px-4 md:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col items-center text-center py-20 md:py-28 lg:py-32">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6 animate-fade-in">
            <span className="block mb-2">Bulk Chemical Manufacturing.</span>
            <span className="block text-primary-600">Reliable and Scalable.</span>
          </h1>
          
          <p className="text-lg md:text-xl text-gray-700 max-w-3xl mb-10 animate-fade-in-up">
            We provide high-quality bulk agrochemical formulations tailored to your specifications.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 animate-fade-in-up delay-300">
            <Button size="lg">Get a Quote</Button>
            <Button variant="outline" size="lg">View Products</Button>
            <Button variant="secondary" size="lg">Partner With Us</Button>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-16 animate-fade-in-up delay-500">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary-600 mb-2">50+</div>
              <div className="text-gray-600">MT monthly production</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary-600 mb-2">25+</div>
              <div className="text-gray-600">branded clients</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary-600 mb-2">100%</div>
              <div className="text-gray-600">customization</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary-600 mb-2">24/7</div>
              <div className="text-gray-600">on-time delivery</div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-white to-transparent"></div>
    </div>
  );
};

export default Hero;