import React from 'react';
import Section from '../ui/Section';
import SectionHeading from '../ui/SectionHeading';
import { MapPin, Truck, Clock, CheckCircle } from 'lucide-react';

const ClientCard: React.FC<{
  name: string;
  quote: string;
  location: string;
}> = ({ name, quote, location }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 relative">
      <div className="absolute top-0 right-0 -mt-4 -mr-4 bg-primary-500 text-white w-8 h-8 rounded-full flex items-center justify-center">
        "
      </div>
      <p className="text-gray-600 italic mb-4">{quote}</p>
      <div className="flex items-center">
        <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center mr-3">
          <span className="text-primary-600 font-bold">{name.charAt(0)}</span>
        </div>
        <div>
          <h4 className="font-semibold">{name}</h4>
          <div className="text-sm text-gray-500 flex items-center">
            <MapPin className="h-3 w-3 mr-1" /> {location}
          </div>
        </div>
      </div>
    </div>
  );
};

const DeliveryFeature: React.FC<{
  icon: React.ReactNode;
  title: string;
  description: string;
}> = ({ icon, title, description }) => {
  return (
    <div className="flex items-start">
      <div className="bg-primary-100 p-3 rounded-lg mr-4 text-primary-600">
        {icon}
      </div>
      <div>
        <h4 className="font-semibold mb-1">{title}</h4>
        <p className="text-gray-600 text-sm">{description}</p>
      </div>
    </div>
  );
};

const Clients: React.FC = () => {
  const clientTestimonials = [
    { 
      name: 'Express Agro Crop Science', 
      quote: 'Timely, consistent, and professional. Their formulations have helped us maintain our brand reputation.', 
      location: 'Madhya Pradesh' 
    },
    { 
      name: 'Farm Agro', 
      quote: "The quality control is impressive. We've never had issues with batch consistency.", 
      location: 'Andhra Pradesh ' 
    },
    { 
      name: 'Indian Crop Care', 
      quote: 'Their R&D support has been invaluable in developing our new product line.', 
      location: 'Telangana' 
    }
  ];

  const coverageStates = ['Madhya Pradesh', 'Andhra Pradesh', 'Telangana', 'Karnataka',];

  return (
    <Section id="clients" bgColor="bg-white">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div>
          <SectionHeading 
            title="Our Valued Clients" 
            subtitle="Trusted by leading agrochemical brands across India."
          />
          
          <div className="space-y-6 mb-8">
            {clientTestimonials.map((client, index) => (
              <ClientCard 
                key={index}
                name={client.name}
                quote={client.quote}
                location={client.location}
              />
            ))}
          </div>
          
          <div className="mt-8">
            <h3 className="text-xl font-semibold mb-4 text-primary-700">Client Coverage</h3>
            <div className="flex flex-wrap gap-2">
              {coverageStates.map((state, index) => (
                <span 
                  key={index} 
                  className="bg-primary-50 text-primary-700 px-3 py-1 rounded-full text-sm"
                >
                  {state}
                </span>
              ))}
            </div>
          </div>
        </div>
        
        <div>
          <SectionHeading 
            title="Delivery Promise" 
            subtitle="Efficient logistics to keep your production running smoothly."
          />
          
          <div className="space-y-8">
            <DeliveryFeature 
              icon={<Clock size={24} />}
              title="7–10 Days for Bulk Orders"
              description="We maintain optimized production schedules to ensure timely delivery of bulk orders within 7-10 business days."
            />
            
            <DeliveryFeature 
              icon={<Truck size={24} />}
              title="Nationwide Logistics"
              description="Our network of trusted logistics partners ensures safe and timely delivery across India."
            />
            
            <DeliveryFeature 
              icon={<CheckCircle size={24} />}
              title="Real-time Batch Tracking"
              description="Stay informed with real-time updates on your order status from production to delivery."
            />
          </div>
          
          <div className="mt-10 bg-primary-50 p-6 rounded-lg">
            <h3 className="text-lg font-semibold mb-3 text-primary-700">Quality Assurance</h3>
            <p className="text-gray-600 mb-4">
              Every batch undergoes rigorous quality testing before dispatch. We provide detailed Certificate of Analysis (COA) with each delivery.
            </p>
            <div className="flex items-center text-primary-600">
              <CheckCircle size={16} className="mr-2" />
              <span className="text-sm font-medium">100% Quality Guaranteed</span>
            </div>
          </div>
        </div>
      </div>
    </Section>
  );
};

export default Clients;