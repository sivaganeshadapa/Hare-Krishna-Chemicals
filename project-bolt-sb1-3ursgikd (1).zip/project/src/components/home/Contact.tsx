import React, { useState } from 'react';
import Section from '../ui/Section';
import SectionHeading from '../ui/SectionHeading';
import Button from '../ui/Button';
import { Mail, Phone, MapPin, Send } from 'lucide-react';

const ContactInfo: React.FC<{
  icon: React.ReactNode;
  title: string;
  content: React.ReactNode;
}> = ({ icon, title, content }) => {
  return (
    <div className="flex items-start">
      <div className="mr-4 text-primary-600">
        {icon}
      </div>
      <div>
        <h3 className="font-medium mb-1">{title}</h3>
        <div className="text-gray-600">{content}</div>
      </div>
    </div>
  );
};

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    email: '',
    phone: '',
    requirement: '',
    volume: '',
    message: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Form submission logic would go here
    alert('Form submitted! We will contact you soon.');
    // Reset form
    setFormData({
      name: '',
      company: '',
      email: '',
      phone: '',
      requirement: '',
      volume: '',
      message: ''
    });
  };

  return (
    <Section id="contact" bgColor="bg-primary-50">
      <SectionHeading 
        title="Let's Grow Together" 
        subtitle="Contact us to discuss how we can support your agrochemical needs."
        center
      />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div className="bg-white rounded-lg shadow-md p-8">
          <h3 className="text-2xl font-semibold mb-6">Get in Touch</h3>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                  Full Name*
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>
              
              <div>
                <label htmlFor="company" className="block text-sm font-medium text-gray-700 mb-1">
                  Company Name*
                </label>
                <input
                  type="text"
                  id="company"
                  name="company"
                  value={formData.company}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Email Address*
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>
              
              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="requirement" className="block text-sm font-medium text-gray-700 mb-1">
                  Product Requirement*
                </label>
                <select
                  id="requirement"
                  name="requirement"
                  value={formData.requirement}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                >
                  <option value="">Select a product category</option>
                  <option value="Bio-Stimulant">Bio-Stimulant</option>
                  <option value="Bio-Pesticides">Bio-Pesticides</option>
                  <option value="Bio-Fungicides">Bio-Fungicides</option>
                  <option value="PGRs">PGRs</option>
                  <option value="Micronutrients">Micronutrients</option>
                  
                  <option value="Bio-Fertilizers">Bio-Fertilizers</option>
                  
                  <option value="Organic Fertilizers">Organic Fertilizers</option>
                  <option value="Water-Soluble Solvents">Water-Soluble Solvents</option>
                  
                  <option value="Intermediates">Intermediates & Solvents</option>
                  <option value="Custom">Custom Formulation</option>
                </select>
              </div>
              
              <div>
                <label htmlFor="volume" className="block text-sm font-medium text-gray-700 mb-1">
                  Estimated Volume
                </label>
                <select
                  id="volume"
                  name="volume"
                  value={formData.volume}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                >
                  <option value="">Select volume range</option>
                  <option value="< 1 MT">Less than 1 MT</option>
                  <option value="1-5 MT">1-5 MT</option>
                  <option value="5-10 MT">5-10 MT</option>
                  <option value="10-20 MT">10-20 MT</option>
                  <option value="> 20 MT">More than 20 MT</option>
                </select>
              </div>
            </div>
            
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                Additional Details
              </label>
              <textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleChange}
                rows={4}
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
              ></textarea>
            </div>
            
            <div>
              <Button type="submit" className="w-full flex justify-center items-center">
                <Send className="mr-2 h-4 w-4" />
                Send Inquiry
              </Button>
            </div>
          </form>
        </div>
        
        <div>
          <div className="bg-white rounded-lg shadow-md p-8 mb-8">
            <h3 className="text-2xl font-semibold mb-6">Contact Information</h3>
            
            <div className="space-y-6">
              <ContactInfo 
                icon={<Mail size={24} />}
                title="Email"
                content={<a href="mailto:chemistswamy@gmail.com" className="hover:text-primary-600 transition-colors">chemistswamy@gmail.com</a>}
              />
              
              <ContactInfo 
                icon={<Phone size={24} />}
                title="Phone"
                content={<a href="tel:+91XXXXXXXXXX" className="hover:text-primary-600 transition-colors">+91 99894 97888</a>}
              />
              
              <ContactInfo 
                icon={<MapPin size={24} />}
                title="Manufacturing Facility"
                content={
                  <address className="not-italic">
                    Plot No. #2-24-105/13/16/D, IDA UPPAL,<br />
                    HYDERABAD, TELANGANA<br />
                    India - 500039
                  </address>
                }
              />
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-8">
            <h3 className="text-xl font-semibold mb-4">Business Hours</h3>
            
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Monday - Friday:</span>
                <span className="font-medium">10:00 AM - 6:00 PM</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Saturday:</span>
                <span className="font-medium">10:00 AM - 1:00 PM</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Sunday:</span>
                <span className="font-medium">Closed</span>
              </div>
            </div>
            
            <div className="mt-6 p-4 bg-primary-50 rounded-md">
              <p className="text-gray-700 text-sm">
                We aim to respond to all inquiries within 24 business hours. 
                For urgent matters, please contact us by phone.
              </p>
            </div>
          </div>
        </div>
      </div>
    </Section>
  );
};

export default Contact;