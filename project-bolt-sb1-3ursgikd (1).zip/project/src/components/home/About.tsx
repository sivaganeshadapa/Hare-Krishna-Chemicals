import React from 'react';
import Section from '../ui/Section';
import SectionHeading from '../ui/SectionHeading';

const About: React.FC = () => {
  return (
    <Section id="about" bgColor="bg-white">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div>
          <SectionHeading 
            title="About Us" 
            subtitle="Committed to excellence in chemical manufacturing since our inception."
          />
          
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-semibold mb-2 text-primary-700">Founder's Story</h3>
              <p className="text-gray-600">
                <b>Mr. Venkata Swamy Akula</b>, a seasoned expert in the chemical industry, began his journey in the <b>R&D division of NACL Industries Ltd.</b>, where he spent years mastering agrochemical formulation and development. With over <b>15 years of hands-on experience</b> in the field and <b>8 successful years at Signova</b>, he envisioned creating a company that delivers <b>reliable, scalable, and ethically manufactured chemical solutions</b>.

Driven by a deep understanding of agrochemical science and a passion for sustainable agriculture, he founded Hare Krishna Chemicals — a company built on innovation, purity, and client-centric manufacturing.
              </p>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-2 text-primary-700">Mission</h3>
              <p className="text-gray-600">
                Support India's agrochemical brands with trusted manufacturing.
              </p>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-2 text-primary-700">Vision</h3>
              <p className="text-gray-600">
                A future where purity meets sustainability.
              </p>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-2 text-primary-700">Our Values</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-primary-50 p-4 rounded-lg">
                  <h4 className="font-medium text-primary-700">Integrity</h4>
                  <p className="text-sm text-gray-600">Honest business practices</p>
                </div>
                <div className="bg-primary-50 p-4 rounded-lg">
                  <h4 className="font-medium text-primary-700">Innovation</h4>
                  <p className="text-sm text-gray-600">Continuous improvement</p>
                </div>
                <div className="bg-primary-50 p-4 rounded-lg">
                  <h4 className="font-medium text-primary-700">Sustainability</h4>
                  <p className="text-sm text-gray-600">Eco-friendly processes</p>
                </div>
                <div className="bg-primary-50 p-4 rounded-lg">
                  <h4 className="font-medium text-primary-700">Client-First</h4>
                  <p className="text-sm text-gray-600">Your success is ours</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="relative">
          <div className="absolute -left-4 -top-4 w-24 h-24 bg-primary-100 rounded-full z-0"></div>
          <div className="absolute -right-4 -bottom-4 w-32 h-32 bg-secondary-100 rounded-full z-0"></div>
          <img 
            src="https://t4.ftcdn.net/jpg/03/73/40/91/240_F_373409163_mD9mOzI3F10TCpuwMtrKSRfkTQx1IMxv.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
            alt="Laboratory equipment" 
            className="rounded-lg shadow-xl relative z-10 w-full h-auto object-cover"
          />
        </div>
      </div>
    </Section>
  );
};

export default About;