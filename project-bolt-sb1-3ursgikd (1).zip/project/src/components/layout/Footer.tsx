import React from 'react';
import Container from '../ui/Container';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-gray-900 text-white py-12">
      <Container>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">Hare Krishna Chemicals</h3>
            <p className="text-gray-300 mb-4">
              Providing high-quality bulk agrochemical formulations tailored to your specifications.
            </p>
            <p className="text-gray-300">
              ISO 9001:2015 Certified
            </p>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><a href="#home" className="text-gray-300 hover:text-white transition-colors">Home</a></li>
              <li><a href="#about" className="text-gray-300 hover:text-white transition-colors">About Us</a></li>
              <li><a href="#products" className="text-gray-300 hover:text-white transition-colors">Products & Services</a></li>
              <li><a href="#clients" className="text-gray-300 hover:text-white transition-colors">Clients & Delivery</a></li>
              <li><a href="#sustainability" className="text-gray-300 hover:text-white transition-colors">Sustainability</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Products</h4>
            <ul className="space-y-2">
               <li><a href="#products" className="text-gray-300 hover:text-white transition-colors">Bio-Stimulant</a></li>
               <li><a href="#products" className="text-gray-300 hover:text-white transition-colors">Bio-Pesticides</a></li>
              <li><a href="#products" className="text-gray-300 hover:text-white transition-colors">Bio-Fungicides</a></li>
               <li><a href="#products" className="text-gray-300 hover:text-white transition-colors">PGRs</a></li>
               <li><a href="#products" className="text-gray-300 hover:text-white transition-colors">Micronutrients</a></li>
              <li><a href="#products" className="text-gray-300 hover:text-white transition-colors">Bio-Fertilizers</a></li>
              
              <li><a href="#products" className="text-gray-300 hover:text-white transition-colors">Organic Fertilizers</a></li>
             
              <li><a href="#products" className="text-gray-300 hover:text-white transition-colors">Water-Soluble Solvents</a></li>
              <li><a href="#products" className="text-gray-300 hover:text-white transition-colors">Intermediates & Solvents</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Us</h4>
            <address className="not-italic text-gray-300">
              <p className="mb-2">Email: <a href="mailto:chemistswamy@gmail.com" className="hover:text-white transition-colors">contact@harekrishnachemicals.com</a></p>
              <p className="mb-2">Phone: +91 99894 97888</p>
            </address>
            <div className="mt-4 flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <span className="sr-only">LinkedIn</span>
                <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" />
                </svg>
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <span className="sr-only">Twitter</span>
                <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723 10.016 10.016 0 01-3.127 1.195 4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.937 4.937 0 004.604 3.417 9.868 9.868 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.054 0 14-7.503 14-14 0-.21 0-.42-.015-.63A9.936 9.936 0 0024 4.59l-.047-.02z" />
                </svg>
              </a>
            </div>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-gray-800 text-center text-gray-400">
          <p>&copy; {currentYear} Hare Krishna Chemicals. All rights reserved.</p>
        </div>
      </Container>
    </footer>
  );
};

export default Footer;