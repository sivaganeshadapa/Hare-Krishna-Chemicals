import React from 'react';
import Container from './Container';

interface SectionProps {
  children: React.ReactNode;
  className?: string;
  id?: string;
  bgColor?: string;
}

const Section: React.FC<SectionProps> = ({ 
  children, 
  className = '',
  id,
  bgColor = 'bg-white'
}) => {
  return (
    <section id={id} className={`py-12 md:py-16 lg:py-20 ${bgColor} ${className}`}>
      <Container>
        {children}
      </Container>
    </section>
  );
};

export default Section;