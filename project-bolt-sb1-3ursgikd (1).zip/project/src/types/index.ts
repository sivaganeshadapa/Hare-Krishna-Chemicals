export interface NavItem {
  name: string;
  href: string;
}

export interface ClientTestimonial {
  name: string;
  quote: string;
  location: string;
}

export interface ProductCategory {
  title: string;
  description: string;
  icon: string;
}

export interface PipelineProject {
  title: string;
  stage: 'Research' | 'Development' | 'Testing' | 'Scaling';
  description: string;
}

export interface ComplianceCertificate {
  title: string;
  status: 'certified' | 'pending' | 'compliant';
  description: string;
}

export interface ContactFormData {
  name: string;
  company: string;
  email: string;
  phone: string;
  requirement: string;
  volume: string;
  message: string;
}